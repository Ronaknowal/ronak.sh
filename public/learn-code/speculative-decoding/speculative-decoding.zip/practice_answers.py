"""Complete changed-input numerical and diagnostic practice answers.

python practice_answers.py
Pure finite computations; no model, training, generation or timing replay.
"""

from fractions import Fraction as F
import json
import numpy as np
from speculative_math import mass_table, residual, expected_tokens, verify_proposal


def changed_tree_answer():
    p = [F(1,2), F(7,20), F(3,20)]
    q = [F(1,5), F(1,5), F(3,5)]
    first = [min(a,b) for a,b in zip(p,q)]
    reject1 = 1-sum(first)
    active = [(a-b)/reject1 for a,b in zip(p,first)]
    second = [min(a,b) for a,b in zip(active,q)]
    reject2 = 1-sum(second)
    repair = [(a-b)/reject2 for a,b in zip(active,second)]
    final = [a+reject1*(b+reject2*c) for a,b,c in zip(first,second,repair)]
    assert final == p
    return {'p':list(map(str,p)), 'q':list(map(str,q)),
            'first_accepted':list(map(str,first)), 'first_rejection':str(reject1),
            'active_residual':list(map(str,active)),
            'second_accepted':list(map(str,second)), 'second_rejection':str(reject2),
            'final_repair':list(map(str,repair)), 'final':list(map(str,final)),
            'reason':'The second proposal tests the updated residual; a further rejection normalizes the remaining deficit again.'}


def answers():
    rows = {}
    p,q = [.4,.1,.5],[.2,.5,.3]
    rows['1'] = {'mass':mass_table(p,q),'repair':residual(p,q).tolist(),
                 'reason':'Common mass .2/.1/.3 plus unconditional deficit .2/0/.2 restores p.'}
    p,q = [.3,.2,.5],[0,.6,.4]
    rows['2'] = {'mass':mass_table(p,q),'repair':residual(p,q).tolist(),
                 'reason':'A is never proposed, but .3 unconditional repair mass reaches A.'}
    p,q = [.12,.88],[.3,.7]
    rows['3'] = {'uniforms':[.399,.4,.401],
                 'accepted':[verify_proposal(p,q,0,u) for u in [.399,.4,.401]],
                 'reason':'Strict half-open comparison rejects the boundary; ideal continuous endpoints have zero probability, finite RNG values need an explicit convention.'}
    rows['4'] = {'K':2,'first_accept_second_reject':['accepted-1','repair'],
                 'all_accept':['accepted-1','accepted-2','bonus'],
                 'repair_eos':['accepted-1','EOS'],
                 'reason':'Stop at EOS immediately, and never retain or emit the later proposed suffix.'}
    correct = [F(3,5)*F(9,10),F(3,5)*F(1,10),F(2,5)*F(1,5),F(2,5)*F(4,5)]
    wrong = [F(3,10)*F(9,10)+F(3,10)*F(1,10),
             F(3,10)*F(1,10)+F(3,10)*F(9,10),F(2,5)*F(1,5),F(2,5)*F(4,5)]
    rows['5'] = {'first_p':['3/5','2/5'],'first_q':['3/10','7/10'],
                 'target_after_A':['9/10','1/10'],'target_after_B':['1/5','4/5'],
                 'stale_q_after_rejected_B':['1/10','9/10'],'paths':['AA','AB','BA','BB'],
                 'correct':list(map(str,correct)),'wrong':list(map(str,wrong)),
                 'reason':'The repaired A needs A context. Reusing B-context q moves .24 mass from AA to AB.'}
    rows['6'] = {'p': [.5,.5],'q':[.5,.5],'baseline_uniform':.25,'after_extra_rng_draw_uniform':.75,
                 'outputs':['A','B'],'reason':'Both marginals can remain p while the particular shared-seed coupling changes.'}
    p,q = [2/3,1/3,0],[.2,.3,.5]
    rows['7'] = {'p':p,'q':q,'mass':mass_table(p,q),'repair':residual(p,q).tolist(),
                 'reason':'Transform and normalize each law before the ratio. Target support excludes C; C proposals reject.'}
    rows['8'] = {'initial_computed':list(range(5)),'draft_positions':[5,6,7,8],
                 'accepted_positions':[5,6],'discarded_candidate_positions':[7,8],
                 'retained_computed':list(range(7)),'pending_repair_position':7,
                 'next_append_input':'Only the repair token at absolute position 7; afterwards computed length becomes 8.'}
    rows['9'] = {'physical_move':'Update page/table address while preserving logical position.',
                 'learned_positions':'Reinterpreting the same row at a new logical index changes its embedding computation.',
                 'rotary':'Do not rotate an already stored key for a different logical position merely because its physical slot changed.'}
    expectation = expected_tokens(.6,3)
    rows['10'] = expectation | {'alpha_zero':expected_tokens(0,3),'alpha_one':expected_tokens(1,3)}
    rows['11'] = {'expected_target_cost':10*expectation['emitted'],
                  'base_denominator':3*2+14+1,'base_speedup':10*expectation['emitted']/21,
                  'higher_overhead_denominator':23,'higher_overhead_speedup':10*expectation['emitted']/23,
                  'reason':'Only the overhead changed; equal acceptance does not guarantee a win.'}
    rows['12'] = {'alpha':.7,'K':2,'expected_emitted':expected_tokens(.7,2)['emitted'],
                  'constructed_round_costs':[10,30],
                  'reason':'Two contexts may have the same overlap and emitted expectation but different draft/verify cost. Different visitation probabilities then change total expected latency; overlap alone is insufficient.'}
    rows['13'] = {'nodes':['root','left','right','left-child'],'depth':[0,1,1,2],
                  'mask':[[1,0,0,0],[1,1,0,0],[1,0,1,0],[1,1,0,1]],
                  'reason':'A node sees ancestors and itself, never its sibling; add the common prompt columns separately.'}
    rows['14'] = changed_tree_answer()
    rows['15'] = {'state_index':'t','target_index':'t+3','wrong_target':'t+2',
                  'frozen_gradients':'Only the new head parameters receive gradients.',
                  'joint_gradients':'Head, backbone and embeddings receive gradients through h_t; the target model may change.'}
    rows['16'] = {'advanced_token_ablation':'Same h_t but different selected x_(t+1) must enter different conditioned predictions; replacing both token embeddings by one constant erases this signal.',
                  'feedback_ablation':'Supplying a fresh target state at every training step removes exposure to recursively generated draft states; retaining three feature taps alone does not preserve the EAGLE-3 training route.',
                  'guarantee':'Neither changed training route alone determines verification exactness; the stated target/proposal correction is a separate requirement.'}
    rows['17'] = {'num_assistant_tokens':5,'num_assistant_tokens_schedule':'constant',
                  'assistant_confidence_threshold':0.0,'assistant_ensemble_weight':None,
                  'reason':'Threshold .4 may stop drafting early. Ensemble .2 targets a mixture, not the original p. Length/EOS can still shorten a fixed-cap round.'}
    rows['18'] = {'records':[{'prompt':'X','arm':'baseline','ms':100,'tokens':10},
                            {'prompt':'X','arm':'speculative','ms':80,'tokens':10},
                            {'prompt':'Y','arm':'baseline','ms':60,'tokens':6},
                            {'prompt':'Y','arm':'speculative','ms':72,'tokens':6}],
                  'paired_speedup':[100/80,60/72],'ms_per_token':[10,8,10,12],
                  'reason':'One pair wins and one loses. No variance estimate or general ranking follows. Freeze prompts, policies, seeds, arms, warmups, order, instrumentation and failure rules before repetitions.'}
    assert rows['3']['accepted']==[True,False,False]
    assert sum(correct)==sum(wrong)==1 and correct!=wrong
    assert abs(rows['10']['emitted']-2.176)<1e-14
    np.testing.assert_allclose(rows['7']['repair'],[14/15,1/15,0],atol=1e-14)
    assert rows['14']['final'] == ['1/2','7/20','3/20']
    return {'passed':True,'answers':rows}


if __name__=='__main__':
    print(json.dumps(answers(),indent=2))
