# Recorded RLVR observations

These are complete once-run observations, including failed and zero outcomes.
The original staged run stopped at native/explicit AdamW update equality.
`observations/trl.status.json` remains failed and no original trl.json exists.
The first separate metrics invocation read the completed custom study without
fitting; `observations/report.json` describes only that metrics invocation.

`native-continuation.json` describes a separately approved own-step arithmetic
audit plus only the unreached mixed fixture: no new update, generation or fit.
`native-score-alignment.json` reports inferred historical numeric row matching;
it does not claim the trainer logged that permutation.

`executed-sources/` preserves the programs that produced the original results.
The ordinary program archive includes readable format-only successors plus the
reviewed native example that reports update inequality separately from each
own-step audit. That full successor main was not scientifically replayed.
`continuation-sources/` preserves the exact fixture-only continuation and audit.

`observations/tiny-study.json` contains all nine histories, full prompts and raw
responses, including extraction failures, all four evaluation checkpoints and
every actual update/skip. `observations/metrics.json` summarizes those histories.
Private model checkpoints are retained separately and are not distributed here.
MANIFEST.json gives exact member hashes; no observations were edited to fit a
preferred result.
