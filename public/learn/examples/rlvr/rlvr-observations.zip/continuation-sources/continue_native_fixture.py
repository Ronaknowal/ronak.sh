"""First execution of the originally planned, previously unreached fixture.

Requires exact different-reviewer prospective acceptance. Reads the failed
native state; no warm training, policy update, generation or evaluation occurs.
The original native status remains failed. Results use a separate destination.
"""

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[6]
DOC = (
    ROOT
    / "docs/teaching/llm-architecture-training/rlvr-reinforcement-learning-with-verifiable-rewards"
)
PUBLIC = ROOT / "public/learn/examples/rlvr"
sys.path.insert(1, str(PUBLIC))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--acceptance", type=Path, required=True)
    parser.add_argument("--acceptance-sha256", required=True)
    args = parser.parse_args()
    assert sha(args.acceptance) == args.acceptance_sha256
    accepted = json.loads(args.acceptance.read_text(encoding="utf-8"))
    packet_path = DOC / "program-continuation/proposal-inputs.json"
    assert accepted["accepted"] is True
    assert accepted["continuation_packet_sha256"] == sha(packet_path)
    packet = json.loads(packet_path.read_text(encoding="utf-8"))
    for relative, expected in packet["files"].items():
        assert sha(ROOT / relative) == expected, "Changed input: " + relative

    output = DOC / "scientific-evidence/native-continuation.json"
    workdir = ROOT / "scratch/rlvr/native-fixture-continuation"
    if output.exists() or workdir.exists():
        raise FileExistsError("Preserve prior continuation; no automatic retry")

    import torch
    from datasets import Dataset
    from transformers import GPT2LMHeadModel, TrainerState
    from trl import GRPOConfig, GRPOTrainer
    from adamw_step_audit import audit_pair
    from trl_bridge import finish_remaining_fixture
    from scientific_journal import ScientificJournal, training_state
    from rlvr_data import (
        INSTRUCTION,
        byte_tokenizer,
        emit,
        load_protocol,
        load_records,
        model_digest,
    )

    journal = ScientificJournal(workdir)
    try:
        protocol = load_protocol()
        settings = protocol["native"]
        torch.set_num_threads(protocol["threads"])
        retained = torch.load(
            ROOT / "scratch/rlvr/study/trl/latest-state.pt", weights_only=False
        )
        assert retained["boundary"] == "native-one-update-parity"
        state, context = retained["state"], retained["state"]["context"]
        assert context["native_step"] == 1
        assert len(context["captured_batches"]) == len(context["losses"]) == 1
        # Arithmetic only, before model construction or the first fixture forward.
        audit = audit_pair(state)
        journal.append("retained-own-step-analytical-audit", audit)
        emit(workdir / "own-step-audit.json", audit)
        assert audit["consistent"]
        assert audit["cross_implementation_equality_passed"] is False
        assert audit["unchanged_cross_implementation_threshold"] == 5e-5

        checkpoint = ROOT / "scratch/rlvr/study/trl/warm"
        model = GPT2LMHeadModel.from_pretrained(
            checkpoint, local_files_only=True
        ).eval()
        model.load_state_dict(state["model"], strict=True)
        tokenizer = byte_tokenizer()
        records = load_records()

        def numeric_reward(*args, **kwargs):
            raise RuntimeError(
                "No reward generation is permitted in fixture continuation"
            )

        config = GRPOConfig(
            output_dir=str(workdir / "trainer"),
            use_cpu=True,
            bf16=False,
            fp16=False,
            max_steps=1,
            per_device_train_batch_size=4,
            gradient_accumulation_steps=1,
            num_generations=4,
            num_iterations=1,
            max_completion_length=12,
            loss_type="grpo",
            scale_rewards="group",
            beta=0.02,
            epsilon=0.2,
            importance_sampling_level="token",
            use_bias_correction_kl=False,
            disable_dropout=True,
            mask_truncated_completions=False,
            temperature=1.0,
            top_p=1.0,
            top_k=0,
            learning_rate=0.0005,
            weight_decay=0.0,
            max_grad_norm=0.0,
            lr_scheduler_type="constant",
            report_to=[],
            push_to_hub=False,
            save_strategy="no",
            disable_tqdm=True,
            seed=19,
            data_seed=19,
            dataloader_num_workers=0,
            use_liger_kernel=False,
            remove_unused_columns=False,
            model_init_kwargs={"local_files_only": True},
        )
        dataset = Dataset.from_list(
            [
                {
                    "prompt": "[BOS]" + row["question"] + INSTRUCTION + "[SEP]",
                    "gold": row["gold"],
                    "record_id": row["id"],
                }
                for row in records["train"]
            ]
        )
        trainer = GRPOTrainer(
            model=model,
            args=config,
            reward_funcs=numeric_reward,
            train_dataset=dataset,
            processing_class=tokenizer,
        )
        trainer.state = TrainerState(**context["trainer_state"])
        trainer.current_gradient_accumulation_steps = 1
        trainer.ref_model.load_state_dict(state["reference"], strict=True)
        trainer.ref_model.requires_grad_(False).eval()
        before = model_digest(model)
        reference_before = model_digest(trainer.ref_model)
        journal.checkpoint(
            training_state(
                model,
                reference=trainer.ref_model,
                configuration=config.to_dict(),
                trainer_state=asdict(trainer.state),
                batch=context["captured_batches"][0],
                original_native_step=1,
                continuation_optimizer_updates=0,
            ),
            "fixture-restored-before-first-forward",
        )
        fixture = finish_remaining_fixture(
            trainer,
            model,
            settings,
            context["captured_batches"][0],
            context["reward_calls"],
            journal,
        )
        result = {
            "original_native_status": "failed",
            "original_update_equality_passed": False,
            "original_native_optimizer_updates": 1,
            "continuation_optimizer_updates": 0,
            "continuation_generated_responses": 0,
            "continuation_warm_updates": 0,
            "own_step_analytical_audit": audit,
            "mixed_fixture": fixture,
            "native_parameters_unchanged": before == model_digest(model),
            "reference_parameters_unchanged": reference_before
            == model_digest(trainer.ref_model),
            "reference_gradients_absent": all(
                p.grad is None for p in trainer.ref_model.parameters()
            ),
            "proposal_packet_sha256": sha(packet_path),
            "acceptance_sha256": args.acceptance_sha256,
            "scope": "Previously unreached declared mixed fixture on retained native batch and state; not replay of the failed native step",
        }
        journal.append("fixture-result-before-final-guards", result)
        emit(workdir / "fixture-result.json", result)
        assert (
            result["native_parameters_unchanged"]
            and result["reference_parameters_unchanged"]
        )
        assert result["reference_gradients_absent"]
        for relative, expected in packet["files"].items():
            assert sha(ROOT / relative) == expected, (
                "Input changed during continuation: " + relative
            )
        emit(output, result)
        journal.append("continuation-completed", {"output": str(output)})
    except BaseException as exception:
        journal.failure(journal.location, exception)
        raise
    print(
        {
            "original_native_status": "failed",
            "fixture_completed": True,
            "continuation_optimizer_updates": 0,
            "continuation_generated_responses": 0,
        }
    )


if __name__ == "__main__":
    main()
