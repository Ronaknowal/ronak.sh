# Files and their roles

| File | Use |
|---|---|
| verifier_contracts.py | Numeric spans, restricted arithmetic AST and small formal proof checker. |
| math_verify_bridge.py | Actual Math-Verify and TRL accuracy-reward contracts. |
| group_gradients.py | Finite objective, enumerated group gradients, signed clipping, KL routes and finite task scheduler. |
| reward_noise.py | Class-conditional error channel, oracle correction and literal correlated-test masks. |
| tiny_causal_rlvr.py | Complete custom causal warm-up, sampling, scoring, updates and evaluations. |
| hf_eval_math.py | Greedy cached Flan-T5-small predictions on the 12 untouched tasks. |
| trl_bridge.py | One actual native GRPO step and matched explicit forward/gradient/update checks. |
| evaluate_rollouts.py | Retained run histories, metrics, work counts and pass@K boundaries. |
| run_all.py | Guarded staged workflow and source-matched result reuse. |
| rlvr_data.py | Fixed bytes, offline inputs, causal mask packing, hashing and usual fast-tokenizer bridge. |
| causal_backbone.py | Exact earlier TinyLM attention/block/model classes. |
| scientific_journal.py | Durable event log, fresh-destination guard and coherent private state checkpoints. |
| backbone-provenance.json | Original source hash and complete class-AST equality. |
| records.json | All 24 train/12 test original questions and solutions, with derived numeric labels. |
| provenance.json | Official dataset revision, selection and original bytes. |
| GSM8K-LICENSE.txt | Complete dataset MIT notice. |
| protocol.json | Prospective architecture, seeds, fixed budgets and exact native settings. |
| study-protocol.md | Protocol interpretation, denominators and failure handling. |
| requirements.txt | Pinned package versions. |
| README.md | Setup and actual commands. |

The `observations` directory, when produced, holds complete JSON results and
their individual source/status/stdout/stderr records. Private weight checkpoints
belong in the separately selected work directory.
